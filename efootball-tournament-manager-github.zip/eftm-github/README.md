# ⚽ eFootball Tournament Manager

[![Backend](https://img.shields.io/badge/Backend-Node.js%20%2B%20Express-green?logo=node.js)](backend/)
[![Database](https://img.shields.io/badge/Database-MongoDB-green?logo=mongodb)](https://mongodb.com)
[![User App](https://img.shields.io/badge/User%20App-Netlify-blue?logo=netlify)](frontend-user/)
[![Admin App](https://img.shields.io/badge/Admin%20App-Netlify-blue?logo=netlify)](frontend-admin/)
[![CI](https://img.shields.io/badge/CI-GitHub%20Actions-black?logo=github)](/.github/workflows)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

A complete, production-ready web system for managing eFootball tournaments — automated player allocation, group-stage round-robin, live standings, and knockout bracket progression. Two separate frontends (user + admin) share one backend API and one MongoDB database.

---

## 🗂 Repository Structure

```
efootball-tournament-manager/
│
├── 📁 backend/                     → Node.js + Express REST API
│   ├── src/
│   │   ├── controllers/            → Auth, players, tournaments, fixtures, results
│   │   ├── middleware/auth.js      → JWT verification
│   │   ├── models/                 → Player, Tournament, Group, Match, Admin
│   │   ├── routes/                 → Express route files
│   │   ├── utils/db.js             → MongoDB connection
│   │   └── utils/tournamentEngine.js  → Core bracket + allocation logic
│   │   └── server.js               → App entry point
│   ├── .env.example                → Template — copy to .env and fill in values
│   ├── package.json
│   └── render.yaml                 → Render deployment config
│
├── 📁 frontend-user/               → Public user app (no login required)
│   ├── index.html
│   ├── config.js                   ← SET YOUR API URL HERE before deploying
│   ├── _redirects                  → Netlify SPA routing fix
│   ├── netlify.toml                → Netlify config
│   └── src/
│       ├── styles/main.css
│       ├── services/api.js
│       ├── components/
│       └── pages/
│
├── 📁 frontend-admin/              → Admin panel (JWT login required)
│   ├── index.html
│   ├── config.js                   ← SET YOUR API URL HERE before deploying
│   ├── _redirects
│   ├── netlify.toml
│   └── src/
│       ├── styles/admin.css
│       ├── services/api.js
│       └── app.js
│
├── 📁 .github/
│   └── workflows/
│       ├── deploy-backend.yml      → Auto-trigger Render deploy on push
│       └── validate-frontend.yml  → Check required files on every PR
│
├── .gitignore
├── package.json                    → Root convenience scripts
└── README.md
```

---

## ✨ Features

| Feature | Detail |
|---|---|
| 🔄 Auto-allocation | `total_players // 36` full tournaments + 1 smaller for remainder |
| ⚽ Group Stage | 36 players → 9 groups × 4, full round-robin (6 matches per group) |
| 📊 Live Standings | Points → GD → GF auto-ranked after each result |
| 🚀 Knockout Bracket | Top 2 per group → bye system → Prelim → R16 → QF → SF → Final |
| 🛡 Admin Panel | JWT-protected: enter results, generate fixtures, view all data |
| 👤 User App | Register, browse tournaments, fixtures, standings — read only |
| 🔗 Shared Data | Both frontends use the same API + MongoDB — real-time consistency |

---

## 🛠 Local Development Setup

### Prerequisites

- [Node.js 18+](https://nodejs.org)
- [MongoDB Atlas](https://mongodb.com/cloud/atlas) account (free tier works)
- Git

### 1 — Clone

```bash
git clone https://github.com/YOUR-USERNAME/efootball-tournament-manager.git
cd efootball-tournament-manager
```

### 2 — Backend

```bash
cd backend
npm install
cp .env.example .env
```

Edit `backend/.env`:

```env
PORT=5000
MONGODB_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/efootball
JWT_SECRET=replace_this_with_a_long_random_string_at_least_32_chars
JWT_EXPIRES_IN=7d
ADMIN_USERNAME=admin
ADMIN_PASSWORD=YourSecurePassword123!
FRONTEND_USER_URL=http://localhost:3000
FRONTEND_ADMIN_URL=http://localhost:3001
NODE_ENV=development
```

```bash
npm run dev
# API is live at → http://localhost:5000
```

### 3 — Create the admin account (one-time)

```bash
curl -X POST http://localhost:5000/api/auth/seed
# Expected: {"message":"Admin account created successfully"}
```

### 4 — User App

```bash
# From the root of the repo:
npx serve frontend-user -p 3000
# Open → http://localhost:3000
```

### 5 — Admin App

```bash
npx serve frontend-admin -p 3001
# Open → http://localhost:3001
# Login with credentials from your .env ADMIN_USERNAME / ADMIN_PASSWORD
```

---

## ☁️ Production Deployment

### Step 1 — Deploy Backend to Render

1. Push this repo to GitHub (see [Pushing to GitHub](#-pushing-to-github) below)
2. Go to [render.com](https://render.com) → **New Web Service**
3. Connect repo → set **Root Directory:** `backend`
4. Set:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** `Node`
5. Add environment variables (Render Dashboard → Environment):

| Key | Value |
|-----|-------|
| `MONGODB_URI` | Your Atlas connection string |
| `JWT_SECRET` | Long random secret (32+ chars) |
| `JWT_EXPIRES_IN` | `7d` |
| `ADMIN_USERNAME` | Your admin username |
| `ADMIN_PASSWORD` | Your secure password |
| `FRONTEND_USER_URL` | `https://YOUR-USER-APP.netlify.app` |
| `FRONTEND_ADMIN_URL` | `https://YOUR-ADMIN-APP.netlify.app` |
| `NODE_ENV` | `production` |

6. Deploy. Copy your API URL: `https://YOUR-API.onrender.com`
7. Seed admin: `curl -X POST https://YOUR-API.onrender.com/api/auth/seed`

---

### Step 2 — Deploy User App to Netlify

1. **Edit `frontend-user/config.js`:**
   ```js
   window.EFOOTBALL_API_URL = 'https://YOUR-API.onrender.com/api';
   ```
2. Commit and push.
3. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**
4. Connect this repo. Set:
   - **Base directory:** `frontend-user`
   - **Build command:** *(leave empty — no build needed)*
   - **Publish directory:** `.`
5. Deploy. Note your URL: `https://YOUR-USER-APP.netlify.app`

---

### Step 3 — Deploy Admin App to Netlify

1. **Edit `frontend-admin/config.js`:**
   ```js
   window.EFOOTBALL_API_URL = 'https://YOUR-API.onrender.com/api';
   ```
2. Commit and push.
3. Create a **second separate Netlify site** from the same repo:
   - **Base directory:** `frontend-admin`
   - **Build command:** *(leave empty)*
   - **Publish directory:** `.`
4. Deploy. Note the URL: `https://YOUR-ADMIN-APP.netlify.app`
5. Go back to Render → update `FRONTEND_ADMIN_URL` to this URL → redeploy.

---

## 📤 Pushing to GitHub

If you downloaded the project as a ZIP:

```bash
# 1 — Enter the project folder
cd efootball-tournament-manager

# 2 — Initialize git
git init

# 3 — Stage all files
git add .

# 4 — First commit
git commit -m "Initial commit: eFootball Tournament Manager"

# 5 — Create a new repo at github.com/new, then:
git remote add origin https://github.com/YOUR-USERNAME/efootball-tournament-manager.git
git branch -M main
git push -u origin main
```

After that, every update is:

```bash
git add .
git commit -m "describe your change"
git push
```

> ⚠️ **Never commit `.env`** — it is in `.gitignore`. Only `.env.example` is committed.

---

## ⚙️ GitHub Actions (CI/CD)

| Workflow | When it runs | What it does |
|----------|-------------|--------------|
| `deploy-backend.yml` | Push to `main` touching `backend/**` | Syntax-checks code, triggers Render webhook |
| `validate-frontend.yml` | Push or PR on any frontend folder | Confirms `index.html`, `_redirects`, `netlify.toml`, `config.js` all exist |

### Enable auto-deploy on Render (optional)

1. Render → your service → **Settings** → **Deploy Hook** → copy the URL
2. GitHub → repo **Settings** → **Secrets and variables** → **Actions** → **New secret**
3. Name: `RENDER_DEPLOY_HOOK_URL`, Value: the Render URL
4. Now every push to `main` that changes `backend/` triggers an auto-deploy.

---

## 🔌 API Reference

### Public

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | Health check |
| `POST` | `/api/players/register` | Register player |
| `GET` | `/api/players` | All players |
| `GET` | `/api/tournaments` | All tournaments |
| `GET` | `/api/tournaments/:id` | Tournament detail |
| `GET` | `/api/tournaments/:id/standings` | Group standings |
| `GET` | `/api/fixtures` | Fixtures (query: `stage`, `played`) |

### Admin (requires `Authorization: Bearer <token>`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/auth/login` | Get JWT token |
| `POST` | `/api/auth/seed` | Create admin account (once) |
| `GET` | `/api/admin/dashboard` | Dashboard stats |
| `POST` | `/api/fixtures/generate/:id` | Generate group fixtures |
| `POST` | `/api/fixtures/generate-knockout/:id` | Generate knockout bracket |
| `POST` | `/api/results/:matchId` | Enter/edit match score |

---

## 🔒 Security

- `.env` never committed — see `.gitignore`
- Passwords hashed with bcrypt (12 rounds)
- JWT with configurable expiry
- CORS locked to configured Netlify domains
- Helmet.js headers on all API responses
- Rate limiting: 200 req/15 min, 10 registrations/hour

---

## 🏗 Tech Stack

| Layer | Tech |
|-------|------|
| API | Node.js 20, Express 4 |
| Database | MongoDB Atlas + Mongoose |
| Auth | JSON Web Tokens + bcryptjs |
| User Frontend | HTML5 / CSS3 / Vanilla JS |
| Admin Frontend | HTML5 / CSS3 / Vanilla JS |
| API Hosting | Render |
| Frontend Hosting | Netlify (2 separate sites) |
| CI/CD | GitHub Actions |

---

## 📄 License

MIT — free to use, fork, and modify.

const Tournament = require('../models/Tournament');
const Group = require('../models/Group');
const Match = require('../models/Match');
const Player = require('../models/Player');

// GET /api/tournaments
exports.getAll = async (req, res) => {
  try {
    const tournaments = await Tournament.find()
      .populate('championId', 'playerName teamName')
      .sort({ createdAt: 1 });

    const enriched = await Promise.all(tournaments.map(async (t) => {
      const playerCount = await Player.countDocuments({ tournamentId: t._id });
      const matchCount = await Match.countDocuments({ tournamentId: t._id });
      const playedCount = await Match.countDocuments({ tournamentId: t._id, played: true });
      return {
        ...t.toObject(),
        playerCount,
        matchCount,
        playedCount,
        progress: matchCount ? Math.round(playedCount / matchCount * 100) : 0,
      };
    }));

    res.json({ count: enriched.length, tournaments: enriched });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/tournaments/:id
exports.getById = async (req, res) => {
  try {
    const t = await Tournament.findById(req.params.id).populate('championId', 'playerName teamName');
    if (!t) return res.status(404).json({ error: 'Tournament not found' });

    const players = await Player.find({ tournamentId: t._id }).sort({ registeredAt: 1 });
    const groups = await Group.find({ tournamentId: t._id })
      .populate('playerIds', 'playerName teamName')
      .populate('standings.playerId', 'playerName teamName')
      .populate('qualified', 'playerName teamName')
      .sort({ name: 1 });
    const matches = await Match.find({ tournamentId: t._id })
      .populate('homePlayer', 'playerName teamName')
      .populate('awayPlayer', 'playerName teamName')
      .populate('winnerId', 'playerName teamName')
      .sort({ matchOrder: 1 });

    res.json({ tournament: t, players, groups, matches });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/tournaments/:id/standings
exports.getStandings = async (req, res) => {
  try {
    const groups = await Group.find({ tournamentId: req.params.id })
      .populate('standings.playerId', 'playerName teamName')
      .sort({ name: 1 });
    res.json({ groups });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

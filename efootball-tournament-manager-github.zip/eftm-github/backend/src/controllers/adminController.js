const Player = require('../models/Player');
const Tournament = require('../models/Tournament');
const Match = require('../models/Match');
const Group = require('../models/Group');

// GET /api/admin/dashboard
exports.dashboard = async (req, res) => {
  try {
    const [playerCount, tournamentCount, matchCount, playedCount, pendingCount] = await Promise.all([
      Player.countDocuments(),
      Tournament.countDocuments(),
      Match.countDocuments(),
      Match.countDocuments({ played: true }),
      Match.countDocuments({ played: false }),
    ]);

    const tournaments = await Tournament.find()
      .populate('championId', 'playerName teamName')
      .sort({ createdAt: 1 });

    const enriched = await Promise.all(tournaments.map(async (t) => {
      const pCount = await Player.countDocuments({ tournamentId: t._id });
      const mCount = await Match.countDocuments({ tournamentId: t._id });
      const pldCount = await Match.countDocuments({ tournamentId: t._id, played: true });
      return { ...t.toObject(), playerCount: pCount, matchCount: mCount, playedCount: pldCount };
    }));

    res.json({
      stats: { playerCount, tournamentCount, matchCount, playedCount, pendingCount },
      tournaments: enriched,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

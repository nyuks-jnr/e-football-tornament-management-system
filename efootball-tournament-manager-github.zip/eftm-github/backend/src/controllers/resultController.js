const Match = require('../models/Match');
const { updateGroupStandings, advanceKnockout } = require('../utils/tournamentEngine');

// POST /api/results/:matchId — admin only
exports.updateResult = async (req, res) => {
  try {
    const { homeScore, awayScore } = req.body;

    if (homeScore === undefined || awayScore === undefined) {
      return res.status(400).json({ error: 'homeScore and awayScore are required' });
    }
    if (homeScore < 0 || awayScore < 0 || !Number.isInteger(Number(homeScore)) || !Number.isInteger(Number(awayScore))) {
      return res.status(400).json({ error: 'Scores must be non-negative integers' });
    }

    const match = await Match.findById(req.params.matchId);
    if (!match) return res.status(404).json({ error: 'Match not found' });

    const wasPlayed = match.played;

    match.homeScore = Number(homeScore);
    match.awayScore = Number(awayScore);
    match.played = true;
    match.winnerId = match.homeScore > match.awayScore ? match.homePlayer : match.awayPlayer;
    await match.save();

    // Update group standings if group match
    if (match.stage === 'group' && match.groupId) {
      // Reverse previous result if editing
      if (wasPlayed) {
        await recalculateGroupStandings(match.groupId);
      } else {
        await updateGroupStandings(match);
      }
    }

    // Advance knockout
    if (match.stage === 'knockout') {
      await advanceKnockout(match);
    }

    const updated = await Match.findById(match._id)
      .populate('homePlayer', 'playerName teamName')
      .populate('awayPlayer', 'playerName teamName')
      .populate('winnerId', 'playerName teamName');

    res.json({ message: 'Result updated', match: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Recalculate all standings for a group from scratch
async function recalculateGroupStandings(groupId) {
  const Group = require('../models/Group');
  const group = await Group.findById(groupId);
  if (!group) return;

  // Reset all standings
  group.standings.forEach(s => {
    s.played = 0; s.won = 0; s.drawn = 0; s.lost = 0;
    s.goalsFor = 0; s.goalsAgainst = 0; s.points = 0;
  });

  const matches = await Match.find({ groupId, stage: 'group', played: true });

  matches.forEach(m => {
    const h = group.standings.find(s => s.playerId.equals(m.homePlayer));
    const a = group.standings.find(s => s.playerId.equals(m.awayPlayer));
    if (!h || !a) return;

    h.played++; a.played++;
    h.goalsFor += m.homeScore; h.goalsAgainst += m.awayScore;
    a.goalsFor += m.awayScore; a.goalsAgainst += m.homeScore;

    if (m.homeScore > m.awayScore) { h.won++; h.points += 3; a.lost++; }
    else if (m.homeScore < m.awayScore) { a.won++; a.points += 3; h.lost++; }
    else { h.drawn++; h.points++; a.drawn++; a.points++; }
  });

  const allGroupMatches = await Match.find({ groupId, stage: 'group' });
  if (allGroupMatches.every(m => m.played)) {
    group.standings.sort((a, b) =>
      b.points - a.points ||
      (b.goalsFor - b.goalsAgainst) - (a.goalsFor - a.goalsAgainst) ||
      b.goalsFor - a.goalsFor
    );
    group.qualified = group.standings.slice(0, 2).map(s => s.playerId);
    group.complete = true;
  }

  await group.save();
}

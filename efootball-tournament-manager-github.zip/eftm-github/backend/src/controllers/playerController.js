const Player = require('../models/Player');
const { rebalanceTournaments } = require('../utils/tournamentEngine');

// POST /api/players/register
exports.register = async (req, res) => {
  try {
    const { playerName, teamName } = req.body;

    if (!playerName || !teamName) {
      return res.status(400).json({ error: 'Player name and team name are required' });
    }

    const existing = await Player.findOne({ playerName: { $regex: `^${playerName.trim()}$`, $options: 'i' } });
    if (existing) {
      return res.status(409).json({ error: 'A player with this name already exists' });
    }

    const player = await Player.create({ playerName: playerName.trim(), teamName: teamName.trim() });

    // Re-balance tournament allocation
    await rebalanceTournaments();

    // Return player with updated tournament info
    const updated = await Player.findById(player._id).populate('tournamentId', 'name').populate('groupId', 'name');
    res.status(201).json({ message: 'Player registered successfully', player: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/players
exports.getAll = async (req, res) => {
  try {
    const players = await Player.find()
      .populate('tournamentId', 'name phase')
      .populate('groupId', 'name')
      .sort({ registeredAt: 1 });
    res.json({ count: players.length, players });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/players/:id
exports.getById = async (req, res) => {
  try {
    const player = await Player.findById(req.params.id)
      .populate('tournamentId', 'name phase')
      .populate('groupId', 'name');
    if (!player) return res.status(404).json({ error: 'Player not found' });
    res.json({ player });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

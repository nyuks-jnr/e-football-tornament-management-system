const Match = require('../models/Match');
const { generateGroupFixtures, generateKnockoutStage } = require('../utils/tournamentEngine');

// GET /api/fixtures?tournamentId=&stage=&round=&played=
exports.getAll = async (req, res) => {
  try {
    const filter = {};
    if (req.query.tournamentId) filter.tournamentId = req.query.tournamentId;
    if (req.query.stage) filter.stage = req.query.stage;
    if (req.query.round) filter.round = req.query.round;
    if (req.query.played !== undefined) filter.played = req.query.played === 'true';

    const matches = await Match.find(filter)
      .populate('homePlayer', 'playerName teamName')
      .populate('awayPlayer', 'playerName teamName')
      .populate('winnerId', 'playerName teamName')
      .populate('groupId', 'name')
      .sort({ round: 1, matchOrder: 1 });

    res.json({ count: matches.length, fixtures: matches });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/fixtures/generate/:tournamentId — admin only
exports.generateGroup = async (req, res) => {
  try {
    const result = await generateGroupFixtures(req.params.tournamentId);
    res.json({ message: 'Group stage fixtures generated', ...result });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// POST /api/fixtures/generate-knockout/:tournamentId — admin only
exports.generateKnockout = async (req, res) => {
  try {
    const result = await generateKnockoutStage(req.params.tournamentId);
    res.json({ message: 'Knockout stage generated', ...result });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

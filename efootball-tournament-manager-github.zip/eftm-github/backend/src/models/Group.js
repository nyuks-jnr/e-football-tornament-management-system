const mongoose = require('mongoose');

const standingSchema = new mongoose.Schema({
  playerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true },
  played: { type: Number, default: 0 },
  won: { type: Number, default: 0 },
  drawn: { type: Number, default: 0 },
  lost: { type: Number, default: 0 },
  goalsFor: { type: Number, default: 0 },
  goalsAgainst: { type: Number, default: 0 },
  points: { type: Number, default: 0 },
}, { _id: false });

const groupSchema = new mongoose.Schema({
  tournamentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tournament',
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  playerIds: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player',
  }],
  standings: [standingSchema],
  qualified: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player',
  }],
  complete: {
    type: Boolean,
    default: false,
  },
}, { timestamps: true });

groupSchema.index({ tournamentId: 1 });

module.exports = mongoose.model('Group', groupSchema);

const mongoose = require('mongoose');

const playerSchema = new mongoose.Schema({
  playerName: {
    type: String,
    required: [true, 'Player name is required'],
    trim: true,
    minlength: [2, 'Player name must be at least 2 characters'],
    maxlength: [50, 'Player name cannot exceed 50 characters'],
  },
  teamName: {
    type: String,
    required: [true, 'Team name is required'],
    trim: true,
    minlength: [2, 'Team name must be at least 2 characters'],
    maxlength: [50, 'Team name cannot exceed 50 characters'],
  },
  tournamentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tournament',
    default: null,
  },
  groupId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Group',
    default: null,
  },
  registeredAt: {
    type: Date,
    default: Date.now,
  },
}, { timestamps: true });

playerSchema.index({ playerName: 1 });
playerSchema.index({ tournamentId: 1 });

module.exports = mongoose.model('Player', playerSchema);

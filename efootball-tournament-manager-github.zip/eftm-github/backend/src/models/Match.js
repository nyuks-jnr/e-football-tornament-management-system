const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema({
  tournamentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tournament',
    required: true,
  },
  groupId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Group',
    default: null,
  },
  homePlayer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player',
    required: true,
  },
  awayPlayer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player',
    required: true,
  },
  homeScore: {
    type: Number,
    default: null,
  },
  awayScore: {
    type: Number,
    default: null,
  },
  played: {
    type: Boolean,
    default: false,
  },
  stage: {
    type: String,
    enum: ['group', 'knockout'],
    required: true,
  },
  round: {
    type: String,
    enum: ['Group Stage', 'Preliminary', 'Round of 16', 'Quarterfinal', 'Semifinal', 'Final'],
    required: true,
  },
  matchOrder: {
    type: Number,
    default: 0,
  },
  isBye: {
    type: Boolean,
    default: false,
  },
  winnerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player',
    default: null,
  },
}, { timestamps: true });

matchSchema.index({ tournamentId: 1, stage: 1 });
matchSchema.index({ groupId: 1 });
matchSchema.index({ played: 1 });

module.exports = mongoose.model('Match', matchSchema);

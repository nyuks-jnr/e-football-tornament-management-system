const mongoose = require('mongoose');

const tournamentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  maxPlayers: {
    type: Number,
    default: 36,
  },
  phase: {
    type: String,
    enum: ['pending', 'group', 'knockout', 'complete'],
    default: 'pending',
  },
  championId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Player',
    default: null,
  },
  fixturesGenerated: {
    type: Boolean,
    default: false,
  },
  knockoutGenerated: {
    type: Boolean,
    default: false,
  },
}, { timestamps: true });

module.exports = mongoose.model('Tournament', tournamentSchema);

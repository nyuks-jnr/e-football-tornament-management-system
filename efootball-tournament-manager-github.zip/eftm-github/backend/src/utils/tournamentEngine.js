const Player = require('../models/Player');
const Tournament = require('../models/Tournament');
const Group = require('../models/Group');
const Match = require('../models/Match');

// ── HELPERS ──────────────────────────────────────────────────────

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function nextPowerOf2(n) {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

// ── ALLOCATION: Re-assign all players to tournaments ─────────────

async function rebalanceTournaments() {
  const allPlayers = await Player.find().sort({ registeredAt: 1 });
  const total = allPlayers.length;
  if (total === 0) return;

  const fullCount = Math.floor(total / 36);
  const remainder = total % 36;
  const neededCount = fullCount + (remainder > 0 ? 1 : 0);

  // Load existing tournaments
  let tournaments = await Tournament.find().sort({ createdAt: 1 });

  // Create missing tournaments
  while (tournaments.length < neededCount) {
    const idx = tournaments.length + 1;
    const t = await Tournament.create({
      name: `Tournament ${idx}`,
      maxPlayers: tournaments.length < fullCount ? 36 : remainder,
      phase: 'pending',
    });
    tournaments.push(t);
  }

  // Update maxPlayers for the last tournament
  if (remainder > 0) {
    const last = tournaments[neededCount - 1];
    last.maxPlayers = remainder;
    await last.save();
  }

  // Assign players to tournaments in order
  const bulkOps = allPlayers.map((p, i) => {
    const tIdx = Math.min(Math.floor(i / 36), neededCount - 1);
    return {
      updateOne: {
        filter: { _id: p._id },
        update: { $set: { tournamentId: tournaments[tIdx]._id, groupId: null } },
      },
    };
  });
  await Player.bulkWrite(bulkOps);

  return tournaments;
}

// ── GROUP STAGE FIXTURE GENERATION ───────────────────────────────

async function generateGroupFixtures(tournamentId) {
  const tournament = await Tournament.findById(tournamentId);
  if (!tournament) throw new Error('Tournament not found');
  if (tournament.fixturesGenerated) throw new Error('Fixtures already generated for this tournament');

  const players = await Player.find({ tournamentId }).sort({ registeredAt: 1 });
  const n = players.length;
  if (n < 2) throw new Error('Not enough players');

  // Clean up old data for this tournament
  await Group.deleteMany({ tournamentId });
  await Match.deleteMany({ tournamentId, stage: 'group' });

  const shuffled = shuffle(players);
  const groups = [];
  const matches = [];

  if (n >= 36) {
    // 9 groups of 4
    for (let g = 0; g < 9; g++) {
      const groupPlayers = shuffled.slice(g * 4, g * 4 + 4);
      const group = await Group.create({
        tournamentId,
        name: `Group ${String.fromCharCode(65 + g)}`,
        playerIds: groupPlayers.map(p => p._id),
        standings: groupPlayers.map(p => ({
          playerId: p._id,
          played: 0, won: 0, drawn: 0, lost: 0,
          goalsFor: 0, goalsAgainst: 0, points: 0,
        })),
      });
      groups.push(group);

      // Update players
      await Player.updateMany(
        { _id: { $in: groupPlayers.map(p => p._id) } },
        { $set: { groupId: group._id } }
      );

      // Round-robin matches
      let order = 0;
      for (let a = 0; a < groupPlayers.length; a++) {
        for (let b = a + 1; b < groupPlayers.length; b++) {
          matches.push({
            tournamentId,
            groupId: group._id,
            homePlayer: groupPlayers[a]._id,
            awayPlayer: groupPlayers[b]._id,
            stage: 'group',
            round: 'Group Stage',
            matchOrder: order++,
          });
        }
      }
    }
  } else if (n < 4) {
    // Direct knockout — no group stage
    const group = await Group.create({
      tournamentId,
      name: 'Playoff',
      playerIds: shuffled.map(p => p._id),
      standings: shuffled.map(p => ({
        playerId: p._id, played: 0, won: 0, drawn: 0, lost: 0,
        goalsFor: 0, goalsAgainst: 0, points: 0,
      })),
    });
    await Player.updateMany(
      { _id: { $in: shuffled.map(p => p._id) } },
      { $set: { groupId: group._id } }
    );
    // Build immediate knockout
    for (let i = 0; i < shuffled.length - 1; i += 2) {
      matches.push({
        tournamentId,
        groupId: null,
        homePlayer: shuffled[i]._id,
        awayPlayer: shuffled[i + 1]._id,
        stage: 'knockout',
        round: shuffled.length <= 2 ? 'Final' : 'Semifinal',
        matchOrder: i,
      });
    }
    tournament.phase = 'knockout';
  } else {
    // 4–8 players: groups of 3–4
    const groupCount = Math.ceil(n / 4);
    for (let g = 0; g < groupCount; g++) {
      const start = g * 4;
      const end = Math.min(start + 4, n);
      const groupPlayers = shuffled.slice(start, end);
      if (groupPlayers.length < 2) continue;

      const group = await Group.create({
        tournamentId,
        name: `Group ${String.fromCharCode(65 + g)}`,
        playerIds: groupPlayers.map(p => p._id),
        standings: groupPlayers.map(p => ({
          playerId: p._id, played: 0, won: 0, drawn: 0, lost: 0,
          goalsFor: 0, goalsAgainst: 0, points: 0,
        })),
      });
      groups.push(group);
      await Player.updateMany(
        { _id: { $in: groupPlayers.map(p => p._id) } },
        { $set: { groupId: group._id } }
      );
      let order = 0;
      for (let a = 0; a < groupPlayers.length; a++) {
        for (let b = a + 1; b < groupPlayers.length; b++) {
          matches.push({
            tournamentId,
            groupId: group._id,
            homePlayer: groupPlayers[a]._id,
            awayPlayer: groupPlayers[b]._id,
            stage: 'group',
            round: 'Group Stage',
            matchOrder: order++,
          });
        }
      }
    }
  }

  if (matches.length) await Match.insertMany(matches);

  tournament.fixturesGenerated = true;
  tournament.phase = tournament.phase === 'knockout' ? 'knockout' : 'group';
  await tournament.save();

  return { groups, matchCount: matches.length };
}

// ── UPDATE STANDINGS AFTER GROUP RESULT ──────────────────────────

async function updateGroupStandings(match) {
  const group = await Group.findById(match.groupId);
  if (!group) return;

  const homeIdx = group.standings.findIndex(s => s.playerId.equals(match.homePlayer));
  const awayIdx = group.standings.findIndex(s => s.playerId.equals(match.awayPlayer));
  if (homeIdx < 0 || awayIdx < 0) return;

  const h = group.standings[homeIdx];
  const a = group.standings[awayIdx];

  h.played++; a.played++;
  h.goalsFor += match.homeScore; h.goalsAgainst += match.awayScore;
  a.goalsFor += match.awayScore; a.goalsAgainst += match.homeScore;

  if (match.homeScore > match.awayScore) {
    h.won++; h.points += 3; a.lost++;
  } else if (match.homeScore < match.awayScore) {
    a.won++; a.points += 3; h.lost++;
  } else {
    h.drawn++; h.points += 1; a.drawn++; a.points += 1;
  }

  // Check if all group matches are played
  const groupMatches = await Match.find({ groupId: group._id, stage: 'group' });
  if (groupMatches.every(m => m.played)) {
    // Rank standings
    group.standings.sort((a, b) =>
      b.points - a.points ||
      (b.goalsFor - b.goalsAgainst) - (a.goalsFor - a.goalsAgainst) ||
      b.goalsFor - a.goalsFor
    );
    // Top 2 qualify
    group.qualified = group.standings.slice(0, 2).map(s => s.playerId);
    group.complete = true;
  }

  await group.save();
}

// ── GENERATE KNOCKOUT STAGE ───────────────────────────────────────

async function generateKnockoutStage(tournamentId) {
  const tournament = await Tournament.findById(tournamentId);
  if (!tournament) throw new Error('Tournament not found');
  if (tournament.knockoutGenerated) throw new Error('Knockout already generated');

  // Check all group matches are done
  const groupMatches = await Match.find({ tournamentId, stage: 'group' });
  if (groupMatches.length && !groupMatches.every(m => m.played)) {
    throw new Error('All group stage matches must be completed first');
  }

  // Collect qualified players
  const groups = await Group.find({ tournamentId }).sort({ name: 1 });
  let qualified = [];
  groups.forEach(g => {
    const sorted = [...g.standings].sort((a, b) =>
      b.points - a.points ||
      (b.goalsFor - b.goalsAgainst) - (a.goalsFor - a.goalsAgainst) ||
      b.goalsFor - a.goalsFor
    );
    qualified.push(...sorted.slice(0, 2).map(s => ({ playerId: s.playerId, points: s.points, gd: s.goalsFor - s.goalsAgainst, gf: s.goalsFor })));
  });

  if (qualified.length < 2) throw new Error('Not enough qualified players');

  // Sort overall to seed byes
  qualified.sort((a, b) => b.points - a.points || b.gd - a.gd || b.gf - a.gf);

  const n = qualified.length;
  const bracketSize = nextPowerOf2(n);
  const byeCount = bracketSize - n;

  // Players with byes = top byeCount players
  const byePlayers = qualified.slice(0, byeCount).map(q => q.playerId);
  const playoffPlayers = qualified.slice(byeCount).map(q => q.playerId);

  const matches = [];
  let order = 0;

  // Determine round names
  let firstRound;
  const remaining = byePlayers.length + Math.ceil(playoffPlayers.length / 2);

  if (playoffPlayers.length > 0) {
    firstRound = 'Preliminary';
    for (let i = 0; i < playoffPlayers.length; i += 2) {
      if (playoffPlayers[i + 1]) {
        matches.push({
          tournamentId,
          groupId: null,
          homePlayer: playoffPlayers[i],
          awayPlayer: playoffPlayers[i + 1],
          stage: 'knockout',
          round: 'Preliminary',
          matchOrder: order++,
        });
      }
    }
  }

  // Round of 16 — byes advance directly, prelim winners TBD (we store null for now)
  // We generate all rounds up front for the bye players only; prelim winners fill in when results are entered
  // For simplicity: generate R16 for bye players; prelim winners will be added after prelim completes
  const r16Players = shuffle([...byePlayers]);
  const roundName = r16Players.length + Math.ceil(playoffPlayers.length / 2) <= 4 ? 'Semifinal'
    : r16Players.length + Math.ceil(playoffPlayers.length / 2) <= 8 ? 'Quarterfinal'
    : 'Round of 16';

  for (let i = 0; i < r16Players.length; i += 2) {
    if (r16Players[i + 1]) {
      matches.push({
        tournamentId,
        groupId: null,
        homePlayer: r16Players[i],
        awayPlayer: r16Players[i + 1],
        stage: 'knockout',
        round: roundName,
        matchOrder: order++,
      });
    }
  }

  await Match.insertMany(matches);

  tournament.phase = 'knockout';
  tournament.knockoutGenerated = true;
  await tournament.save();

  return { matchCount: matches.length, byeCount, qualifiedCount: n };
}

// ── ADVANCE KNOCKOUT ──────────────────────────────────────────────

async function advanceKnockout(match) {
  const tournament = await Tournament.findById(match.tournamentId);
  if (!tournament || tournament.phase !== 'knockout') return;

  const winnerId = match.homeScore > match.awayScore ? match.homePlayer : match.awayPlayer;
  await Match.findByIdAndUpdate(match._id, { winnerId });

  const roundOrder = ['Preliminary', 'Round of 16', 'Quarterfinal', 'Semifinal', 'Final'];
  const currentIdx = roundOrder.indexOf(match.round);
  if (currentIdx < 0) return;

  // Check if all matches in current round are done
  const roundMatches = await Match.find({ tournamentId: match.tournamentId, round: match.round, stage: 'knockout' });
  if (!roundMatches.every(m => m.played)) return;

  const winners = roundMatches.map(m => m.homeScore > m.awayScore ? m.homePlayer : m.awayPlayer);

  if (match.round === 'Final') {
    tournament.phase = 'complete';
    tournament.championId = winners[0];
    await tournament.save();
    return;
  }

  // Generate next round
  const nextRound = roundOrder[currentIdx + 1];
  const shuffledWinners = shuffle(winners);
  const newMatches = [];
  for (let i = 0; i < shuffledWinners.length; i += 2) {
    if (shuffledWinners[i + 1]) {
      newMatches.push({
        tournamentId: match.tournamentId,
        groupId: null,
        homePlayer: shuffledWinners[i],
        awayPlayer: shuffledWinners[i + 1],
        stage: 'knockout',
        round: nextRound,
        matchOrder: i,
      });
    }
  }
  if (newMatches.length) await Match.insertMany(newMatches);
}

module.exports = {
  rebalanceTournaments,
  generateGroupFixtures,
  generateKnockoutStage,
  updateGroupStandings,
  advanceKnockout,
};

const router = require('express').Router();
const { updateResult } = require('../controllers/resultController');
const { protect } = require('../middleware/auth');

router.post('/:matchId', protect, updateResult);   // Admin only

module.exports = router;

const router = require('express').Router();
const { dashboard } = require('../controllers/adminController');
const { protect } = require('../middleware/auth');

router.get('/dashboard', protect, dashboard);   // Admin only

module.exports = router;

const router = require('express').Router();
const { getAll, getById, getStandings } = require('../controllers/tournamentController');

router.get('/', getAll);                         // Public
router.get('/:id', getById);                     // Public
router.get('/:id/standings', getStandings);      // Public

module.exports = router;

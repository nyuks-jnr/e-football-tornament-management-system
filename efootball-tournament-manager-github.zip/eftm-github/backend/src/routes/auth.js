const router = require('express').Router();
const { login, seed, me } = require('../controllers/authController');
const { protect } = require('../middleware/auth');

router.post('/login', login);
router.post('/seed', seed);        // Run once to create admin account
router.get('/me', protect, me);

module.exports = router;

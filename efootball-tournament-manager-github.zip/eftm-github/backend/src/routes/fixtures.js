const router = require('express').Router();
const { getAll, generateGroup, generateKnockout } = require('../controllers/fixtureController');
const { protect } = require('../middleware/auth');

router.get('/', getAll);                                                    // Public
router.post('/generate/:tournamentId', protect, generateGroup);             // Admin only
router.post('/generate-knockout/:tournamentId', protect, generateKnockout); // Admin only

module.exports = router;

const router = require('express').Router();
const { register, getAll, getById } = require('../controllers/playerController');
const { protect } = require('../middleware/auth');

router.post('/register', register);          // Public
router.get('/', getAll);                     // Public
router.get('/:id', getById);                 // Public

module.exports = router;

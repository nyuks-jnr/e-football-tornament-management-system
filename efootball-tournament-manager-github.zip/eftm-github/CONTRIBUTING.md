# Contributing to eFootball Tournament Manager

Thanks for your interest! Here's how to contribute effectively.

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR-USERNAME/efootball-tournament-manager.git`
3. Create a branch: `git checkout -b feature/your-feature-name`
4. Set up locally (see README.md)

## Project Layout

- **Backend changes** → edit files in `backend/src/`
- **User app changes** → edit files in `frontend-user/src/`
- **Admin app changes** → edit files in `frontend-admin/src/`
- **Tournament logic** → `backend/src/utils/tournamentEngine.js`

## Before Submitting a PR

- [ ] Tested locally — backend + both frontends work
- [ ] No `.env` file included in the commit
- [ ] `config.js` still has the placeholder URL (not a real key)
- [ ] `_redirects` and `netlify.toml` are untouched unless intentionally changed
- [ ] Commit message is clear: `fix: correct standings sort order`

## Commit Message Format

```
type: short description

Types: feat | fix | docs | style | refactor | chore
```

Examples:
- `feat: add group stage tiebreaker by head-to-head`
- `fix: prevent duplicate player registration`
- `docs: update deployment instructions`

## Questions?

Open an issue with the `question` label.

## What does this PR do?

<!-- Briefly describe what changed -->

## Type of change
- [ ] Bug fix
- [ ] New feature
- [ ] Backend change
- [ ] Frontend change (user app)
- [ ] Frontend change (admin app)
- [ ] Documentation update

## Checklist
- [ ] I tested this locally
- [ ] No `.env` files are included in this PR
- [ ] `config.js` still uses the placeholder URL (not a real API key)
- [ ] The `_redirects` file is untouched

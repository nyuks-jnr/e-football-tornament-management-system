// ── APP BOOTSTRAP ────────────────────────────────────────────────

const PAGES = ['home','register','tournaments','standings','fixtures'];
let currentPage = 'home';

function navigate(page) {
  if (!PAGES.includes(page)) return;
  PAGES.forEach(p => {
    document.getElementById(`page-${p}`).classList.remove('active');
    document.querySelectorAll(`.nav-link[data-page="${p}"]`).forEach(l => l.classList.remove('active'));
  });
  document.getElementById(`page-${page}`).classList.add('active');
  document.querySelectorAll(`.nav-link[data-page="${page}"]`).forEach(l => l.classList.add('active'));
  currentPage = page;

  // Close mobile menu
  document.getElementById('nav-links').classList.remove('open');

  // Load page data
  switch (page) {
    case 'home':        loadHome();        break;
    case 'register':    loadPlayers();     break;
    case 'tournaments': loadTournaments(); break;
    case 'standings':   renderStandings(); break;
    case 'fixtures':    loadFixtures();    break;
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function toggleMenu() {
  document.getElementById('nav-links').classList.toggle('open');
}

// ── PARTICLES ────────────────────────────────────────────────────
(function spawnParticles() {
  const container = document.getElementById('particles');
  const colors    = ['#00fff7','#ff00c8','#39ff14','#ffe600','#ff6b00'];
  for (let i = 0; i < 35; i++) {
    const el    = document.createElement('div');
    el.className = 'particle';
    const color = colors[Math.floor(Math.random() * colors.length)];
    const size  = 1 + Math.random() * 2;
    el.style.cssText = `
      left:${Math.random() * 100}%;
      width:${size}px; height:${size}px;
      background:${color};
      box-shadow:0 0 ${size * 3}px ${color};
      --dx:${(Math.random() - 0.5) * 180}px;
      animation-duration:${9 + Math.random() * 14}s;
      animation-delay:-${Math.random() * 23}s;
    `;
    container.appendChild(el);
  }
})();

// ── INIT ─────────────────────────────────────────────────────────
(async function init() {
  // Check API health
  try { await API.health(); } catch (_) {
    console.warn('API unreachable. Check backend URL.');
  }
  navigate('home');
})();

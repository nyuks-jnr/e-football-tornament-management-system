// ── API SERVICE ──────────────────────────────────────────────────
// Set your backend URL here or via a config file

const API_BASE = window.EFOOTBALL_API_URL || 'http://localhost:5000/api';

async function apiFetch(path, options = {}) {
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      headers: { 'Content-Type': 'application/json', ...options.headers },
      ...options,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  } catch (err) {
    console.error(`API Error [${path}]:`, err.message);
    throw err;
  }
}

const API = {
  // Players
  registerPlayer: (body) => apiFetch('/players/register', { method: 'POST', body: JSON.stringify(body) }),
  getPlayers:     ()     => apiFetch('/players'),
  getPlayer:      (id)   => apiFetch(`/players/${id}`),

  // Tournaments
  getTournaments:    ()   => apiFetch('/tournaments'),
  getTournament:     (id) => apiFetch(`/tournaments/${id}`),
  getTournStandings: (id) => apiFetch(`/tournaments/${id}/standings`),

  // Fixtures
  getFixtures: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([,v]) => v !== '')).toString();
    return apiFetch(`/fixtures${q ? '?' + q : ''}`);
  },

  // Health
  health: () => apiFetch('/health'),
};

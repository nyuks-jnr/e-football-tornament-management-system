// ── HOME PAGE ────────────────────────────────────────────────────

async function loadHome() {
  try {
    const [tData, fData] = await Promise.all([
      API.getTournaments(),
      API.getFixtures(),
    ]);

    const { tournaments } = tData;
    const { fixtures }    = fData;

    // Stats
    const playerCount = tournaments.reduce((a, t) => a + (t.playerCount || 0), 0);
    const played      = fixtures.filter(f => f.played).length;
    const pending     = fixtures.filter(f => !f.played).length;

    document.getElementById('s-players').textContent     = playerCount;
    document.getElementById('s-tournaments').textContent = tournaments.length;
    document.getElementById('s-played').textContent      = played;
    document.getElementById('s-pending').textContent     = pending;

    // Latest results (last 5 played)
    const results = fixtures.filter(f => f.played).slice(-5).reverse();
    const resEl   = document.getElementById('home-results');
    resEl.innerHTML = results.length
      ? results.map(buildMatchCard).join('')
      : emptyState('⚽', 'No results yet');

    // Upcoming fixtures (first 5 pending)
    const upcoming = fixtures.filter(f => !f.played).slice(0, 5);
    const fixEl    = document.getElementById('home-fixtures');
    fixEl.innerHTML = upcoming.length
      ? upcoming.map(buildMatchCard).join('')
      : emptyState('📅', 'No upcoming fixtures');

  } catch (err) {
    document.getElementById('home-results').innerHTML  = `<div class="alert alert-error">Failed to load: ${err.message}</div>`;
    document.getElementById('home-fixtures').innerHTML = '';
  }
}

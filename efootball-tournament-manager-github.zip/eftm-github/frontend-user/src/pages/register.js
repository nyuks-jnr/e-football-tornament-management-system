// ── REGISTER PAGE ────────────────────────────────────────────────

async function registerPlayer() {
  const name    = document.getElementById('reg-name').value.trim();
  const team    = document.getElementById('reg-team').value.trim();
  const btn     = document.getElementById('reg-btn');

  if (!name || !team) { showAlert('reg-alert','error','Player name and team name are required.'); return; }

  btn.disabled    = true;
  btn.textContent = '⏳ Registering…';

  try {
    await API.registerPlayer({ playerName: name, teamName: team });
    document.getElementById('reg-name').value = '';
    document.getElementById('reg-team').value = '';
    showAlert('reg-alert', 'success', `✓ ${name} registered and assigned to a tournament!`);
    loadPlayers();
  } catch (err) {
    showAlert('reg-alert', 'error', err.message);
  } finally {
    btn.disabled    = false;
    btn.textContent = '⚡ Register Player';
  }
}

async function loadPlayers() {
  const tbody = document.getElementById('player-table');
  try {
    const { players } = await API.getPlayers();
    if (!players.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty-cell">No players registered yet</td></tr>';
      return;
    }
    tbody.innerHTML = players.map((p, i) => `
      <tr>
        <td style="font-family:var(--font-mono);color:var(--text-dim)">${i + 1}</td>
        <td><strong>${esc(p.playerName)}</strong></td>
        <td style="color:var(--text-dim)">${esc(p.teamName)}</td>
        <td style="color:var(--neon-cyan);font-family:var(--font-mono);font-size:0.78rem">${p.tournamentId ? esc(p.tournamentId.name) : '—'}</td>
        <td style="color:var(--neon-magenta);font-family:var(--font-mono);font-size:0.78rem">${p.groupId ? esc(p.groupId.name) : '—'}</td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="5" class="empty-cell" style="color:var(--neon-magenta)">Error: ${err.message}</td></tr>`;
  }
}

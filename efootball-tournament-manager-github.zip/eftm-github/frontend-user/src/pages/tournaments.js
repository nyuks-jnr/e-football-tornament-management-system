// ── TOURNAMENTS PAGE ─────────────────────────────────────────────

async function loadTournaments() {
  const el = document.getElementById('tournament-list');
  try {
    const { tournaments } = await API.getTournaments();
    if (!tournaments.length) {
      el.innerHTML = emptyState('🏆', 'No tournaments yet. Register players to begin!');
      return;
    }
    el.innerHTML = `<div class="t-grid">${tournaments.map(t => `
      <div class="t-card" onclick="viewTournament('${t._id}')">
        <div class="t-name">${esc(t.name)}</div>
        <div class="t-meta">
          <span>👥 ${t.playerCount || 0} players</span>
          <span>⚽ ${t.playedCount || 0}/${t.matchCount || 0} matches</span>
          <span class="t-phase phase-${t.phase}">${t.phase}</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${t.progress || 0}%"></div>
        </div>
        ${t.championId ? `<div class="champion-banner">🏆 Champion: ${esc(t.championId.playerName)}</div>` : ''}
      </div>`).join('')}</div>`;
  } catch (err) {
    el.innerHTML = `<div class="alert alert-error">Failed to load: ${err.message}</div>`;
  }
}

function showTournamentList() {
  document.getElementById('tournament-list').style.display   = '';
  document.getElementById('tournament-detail').style.display = 'none';
  loadTournaments();
}

async function viewTournament(id) {
  document.getElementById('tournament-list').style.display   = 'none';
  document.getElementById('tournament-detail').style.display = '';
  const content = document.getElementById('tournament-detail-content');
  content.innerHTML = '<div class="loading-pulse"></div><div class="loading-pulse"></div>';

  try {
    const { tournament: t, groups, matches } = await API.getTournament(id);

    let html = `
      <div style="margin-bottom:2rem">
        <h2 style="font-family:var(--font-display);font-size:1.8rem;letter-spacing:0.1em;color:var(--neon-cyan)">${esc(t.name)}</h2>
        <div style="font-family:var(--font-mono);font-size:0.75rem;color:var(--text-dim);margin-top:0.5rem;display:flex;gap:1.5rem;flex-wrap:wrap">
          <span>Phase: <span style="color:var(--neon-cyan)">${t.phase.toUpperCase()}</span></span>
          <span>Matches: <span style="color:var(--neon-yellow)">${matches.filter(m=>m.played).length}/${matches.length}</span></span>
        </div>
        ${t.championId ? `<div class="champion-banner" style="margin-top:1rem;max-width:400px">
          🏆 CHAMPION: ${esc(t.championId.playerName)} (${esc(t.championId.teamName)})
        </div>` : ''}
      </div>`;

    // Group stage
    const groupStageGroups = groups.filter(g => g.playerIds && g.playerIds.length > 0);
    if (groupStageGroups.length) {
      html += `<div class="section-header"><h2>Group Stage</h2></div>`;
      html += `<div class="standings-grid" style="margin-bottom:2rem">`;
      groupStageGroups.forEach(g => {
        const gMatches = matches.filter(m => m.groupId && m.groupId === g._id || (m.groupId && m.groupId._id === g._id));
        html += `<div class="group-card">
          <div class="group-name">${esc(g.name)}</div>
          ${buildStandingsTable(g.standings)}
          <div style="margin-top:1rem">
            ${matches.filter(m => {
              const gid = m.groupId && (m.groupId._id || m.groupId);
              return String(gid) === String(g._id);
            }).map(buildMatchCard).join('') || '<p class="empty-text">No fixtures yet</p>'}
          </div>
        </div>`;
      });
      html += `</div>`;
    }

    // Knockout
    const koMatches = matches.filter(m => m.stage === 'knockout');
    if (koMatches.length) {
      html += `<div class="section-header"><h2>Knockout Stage</h2></div>`;
      const rounds = ['Preliminary','Round of 16','Quarterfinal','Semifinal','Final'];
      rounds.forEach(round => {
        const rM = koMatches.filter(m => m.round === round);
        if (!rM.length) return;
        html += `<div class="bracket-round">
          <div class="round-label">◈ ${round}</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:0.5rem">
            ${rM.map(buildMatchCard).join('')}
          </div>
        </div>`;
      });
    }

    if (!groupStageGroups.length && !koMatches.length) {
      html += emptyState('📋', 'Fixtures not yet generated for this tournament.');
    }

    content.innerHTML = html;
  } catch (err) {
    content.innerHTML = `<div class="alert alert-error">Failed to load tournament: ${err.message}</div>`;
  }
}

// ── FIXTURES PAGE ────────────────────────────────────────────────

async function loadFixtures() {
  const container = document.getElementById('fixtures-container');
  const stage     = document.getElementById('fixture-stage').value;
  const played    = document.getElementById('fixture-played').value;

  container.innerHTML = '<div class="loading-pulse"></div><div class="loading-pulse"></div><div class="loading-pulse"></div>';

  try {
    const params = {};
    if (stage)  params.stage  = stage;
    if (played !== '') params.played = played;

    const { fixtures, count } = await API.getFixtures(params);

    if (!fixtures.length) {
      container.innerHTML = emptyState('📋', 'No fixtures found.');
      return;
    }

    // Group by tournament then round
    const byTournament = {};
    fixtures.forEach(f => {
      const tid  = f.tournamentId || 'unknown';
      if (!byTournament[tid]) byTournament[tid] = { name: '', rounds: {} };
      if (!byTournament[tid].rounds[f.round]) byTournament[tid].rounds[f.round] = [];
      byTournament[tid].rounds[f.round].push(f);
    });

    // Fetch tournament names
    let tNames = {};
    try {
      const { tournaments } = await API.getTournaments();
      tournaments.forEach(t => { tNames[t._id] = t.name; });
    } catch (_) {}

    const roundOrder = ['Group Stage','Preliminary','Round of 16','Quarterfinal','Semifinal','Final'];

    let html = `<div style="font-family:var(--font-mono);font-size:0.7rem;color:var(--text-dim);margin-bottom:1.5rem">${count} match${count !== 1 ? 'es' : ''} found</div>`;

    Object.entries(byTournament).forEach(([tid, data]) => {
      html += `<div style="margin-bottom:2.5rem">
        <div class="section-header"><h2>${esc(tNames[tid] || 'Tournament')}</h2></div>`;
      roundOrder.forEach(round => {
        if (!data.rounds[round]) return;
        html += `<div class="bracket-round">
          <div class="round-label">◈ ${round}</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:0.5rem">
            ${data.rounds[round].map(buildMatchCard).join('')}
          </div>
        </div>`;
      });
      html += '</div>';
    });

    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">Failed to load fixtures: ${err.message}</div>`;
  }
}

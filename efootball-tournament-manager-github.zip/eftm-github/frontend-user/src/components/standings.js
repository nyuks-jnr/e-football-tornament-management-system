// ── STANDINGS COMPONENT ──────────────────────────────────────────

async function renderStandings() {
  const container = document.getElementById('standings-container');
  try {
    const { tournaments } = await API.getTournaments();
    if (!tournaments.length) {
      container.innerHTML = emptyState('📊', 'No tournaments yet. Register players to begin!');
      return;
    }

    let html = '';
    for (const t of tournaments) {
      if (!t.fixturesGenerated) continue;
      const { groups } = await API.getTournStandings(t._id);
      if (!groups || !groups.length) continue;

      html += `
        <div style="margin-bottom:2.5rem">
          <div class="section-header">
            <h2>${esc(t.name)}</h2>
            <span class="t-phase phase-${t.phase}" style="margin-left:0.5rem">${t.phase}</span>
          </div>
          <div class="standings-grid">
            ${groups.map(g => `
              <div class="group-card">
                <div class="group-name">${esc(g.name)}</div>
                ${buildStandingsTable(g.standings)}
              </div>`).join('')}
          </div>
        </div>`;
    }

    container.innerHTML = html || emptyState('📊', 'Fixtures not yet generated for any tournament.');
  } catch (err) {
    container.innerHTML = `<div class="alert alert-error">Failed to load standings: ${err.message}</div>`;
  }
}

// ── MATCH CARD COMPONENT ─────────────────────────────────────────

function buildMatchCard(match) {
  const home  = match.homePlayer || {};
  const away  = match.awayPlayer || {};
  const group = match.groupId ? `${match.groupId.name} · ` : '';

  if (match.played) {
    const homeWin = match.homeScore > match.awayScore;
    const awayWin = match.awayScore > match.homeScore;
    return `
      <div class="match-card">
        <div class="mc-team right">
          <div class="mc-team-name">${esc(home.playerName || 'TBD')}</div>
          <div class="mc-team-club">${esc(home.teamName  || '')}</div>
        </div>
        <div class="mc-score">${match.homeScore} – ${match.awayScore}</div>
        <div class="mc-team">
          <div class="mc-team-name">${esc(away.playerName || 'TBD')}</div>
          <div class="mc-team-club">${esc(away.teamName  || '')}</div>
        </div>
        <div class="mc-round">${group}${match.round}</div>
      </div>`;
  } else {
    return `
      <div class="match-card">
        <div class="mc-team right">
          <div class="mc-team-name">${esc(home.playerName || 'TBD')}</div>
          <div class="mc-team-club">${esc(home.teamName  || '')}</div>
        </div>
        <div class="mc-score pending">VS</div>
        <div class="mc-team">
          <div class="mc-team-name">${esc(away.playerName || 'TBD')}</div>
          <div class="mc-team-club">${esc(away.teamName  || '')}</div>
        </div>
        <div class="mc-round">${group}${match.round}</div>
      </div>`;
  }
}

function buildStandingsTable(standings) {
  if (!standings || !standings.length) return '<p class="empty-text">No data yet</p>';
  return `
    <table>
      <thead><tr><th>#</th><th>Player</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>GD</th><th>Pts</th></tr></thead>
      <tbody>
        ${standings.map((s, i) => {
          const p  = s.playerId || {};
          const gd = s.goalsFor - s.goalsAgainst;
          const q  = i < 2 ? '<span class="mc-badge badge-q" style="margin-left:0.3rem">Q</span>' : '';
          return `<tr>
            <td style="font-family:var(--font-mono);color:var(--text-dim)">${i + 1}</td>
            <td><strong>${esc(p.playerName || '—')}</strong>${q}<br><span style="font-size:0.72rem;color:var(--text-dim)">${esc(p.teamName || '')}</span></td>
            <td>${s.played}</td><td>${s.won}</td><td>${s.drawn}</td><td>${s.lost}</td>
            <td>${s.goalsFor}</td><td>${s.goalsAgainst}</td>
            <td style="color:${gd >= 0 ? 'var(--neon-green)' : 'var(--neon-magenta)'}">${gd >= 0 ? '+' : ''}${gd}</td>
            <td style="font-family:var(--font-display);color:var(--neon-yellow);font-weight:700">${s.points}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>`;
}

function esc(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showAlert(containerId, type, msg, duration = 4000) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
  if (duration) setTimeout(() => { el.innerHTML = ''; }, duration);
}

function emptyState(icon, text) {
  return `<div class="empty-state"><div class="empty-icon">${icon}</div><p class="empty-text">${text}</p></div>`;
}

// ── ADMIN CONFIGURATION ──────────────────────────────────────────
// Update this URL to point to your deployed backend

window.EFOOTBALL_API_URL = 'https://your-backend.onrender.com/api';

// For local development, change to:
// window.EFOOTBALL_API_URL = 'http://localhost:5000/api';

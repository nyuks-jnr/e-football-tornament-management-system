// ── ADMIN API SERVICE ────────────────────────────────────────────

const API_BASE = window.EFOOTBALL_API_URL || 'http://localhost:5000/api';

function getToken() { return localStorage.getItem('eftm_admin_token') || ''; }

async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { headers, ...options });

  if (res.status === 401) {
    localStorage.removeItem('eftm_admin_token');
    showLoginScreen();
    throw new Error('Session expired. Please log in again.');
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

const API = {
  // Auth
  login:   (body) => apiFetch('/auth/login', { method:'POST', body:JSON.stringify(body) }),
  me:      ()     => apiFetch('/auth/me'),

  // Dashboard
  dashboard: () => apiFetch('/admin/dashboard'),

  // Players
  getPlayers: () => apiFetch('/players'),

  // Tournaments
  getTournaments: ()   => apiFetch('/tournaments'),
  getTournament:  (id) => apiFetch(`/tournaments/${id}`),

  // Fixtures
  getFixtures: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([,v]) => v !== '')).toString();
    return apiFetch(`/fixtures${q ? '?' + q : ''}`);
  },
  generateGroup:   (tid) => apiFetch(`/fixtures/generate/${tid}`, { method:'POST' }),
  generateKnockout:(tid) => apiFetch(`/fixtures/generate-knockout/${tid}`, { method:'POST' }),

  // Results
  updateResult: (matchId, body) => apiFetch(`/results/${matchId}`, { method:'POST', body:JSON.stringify(body) }),
};

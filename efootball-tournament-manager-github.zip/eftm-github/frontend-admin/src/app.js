// ── UTILS ────────────────────────────────────────────────────────
function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function showAlert(id, type, msg, dur = 5000) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
  if (dur) setTimeout(() => { if(el) el.innerHTML = ''; }, dur);
}
function emptyState(icon, text) {
  return `<div class="empty-state"><div class="empty-icon">${icon}</div><p class="empty-text">${text}</p></div>`;
}
function fmtDate(d) {
  return d ? new Date(d).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }) : '—';
}

// ── PARTICLES ────────────────────────────────────────────────────
(function spawnParticles() {
  const c = document.getElementById('particles');
  const colors = ['#ff00c8','#00fff7','#ff6b00','#ffe600','#39ff14'];
  for (let i = 0; i < 30; i++) {
    const el = document.createElement('div');
    el.className = 'particle';
    const col = colors[Math.floor(Math.random() * colors.length)];
    const sz  = 1 + Math.random() * 2;
    el.style.cssText = `left:${Math.random()*100}%;width:${sz}px;height:${sz}px;background:${col};box-shadow:0 0 ${sz*3}px ${col};--dx:${(Math.random()-.5)*160}px;animation-duration:${10+Math.random()*14}s;animation-delay:-${Math.random()*24}s`;
    c.appendChild(el);
  }
})();

// ── AUTH ─────────────────────────────────────────────────────────
function showLoginScreen() {
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('admin-app').style.display    = 'none';
}
function showAdminApp() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('admin-app').style.display    = '';
}

async function doLogin() {
  const username = document.getElementById('login-user').value.trim();
  const password = document.getElementById('login-pass').value;
  const btn      = document.getElementById('login-btn');

  if (!username || !password) { showAlert('login-alert','error','Username and password required.'); return; }

  btn.disabled    = true;
  btn.textContent = '⏳ Logging in…';

  try {
    const data = await API.login({ username, password });
    localStorage.setItem('eftm_admin_token', data.token);
    showAdminApp();
    switchTab('dashboard');
  } catch (err) {
    showAlert('login-alert','error', err.message);
  } finally {
    btn.disabled    = false;
    btn.textContent = '🛡 Access Admin Panel';
  }
}

function doLogout() {
  localStorage.removeItem('eftm_admin_token');
  document.getElementById('login-pass').value = '';
  showLoginScreen();
}

// ── TAB SWITCHING ─────────────────────────────────────────────────
const TABS = ['dashboard','results','fixtures','players','generate'];

function switchTab(tab) {
  TABS.forEach(t => {
    document.getElementById(`tab-${t}`).classList.toggle('active', t === tab);
    document.querySelectorAll(`.nav-link[data-tab="${t}"]`).forEach(l => l.classList.toggle('active', t === tab));
  });
  switch(tab) {
    case 'dashboard': loadDashboard();      break;
    case 'results':   loadResults();        break;
    case 'fixtures':  loadAdminFixtures();  break;
    case 'players':   loadPlayers();        break;
    case 'generate':  loadGenerate();       break;
  }
}

// ── DASHBOARD ────────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const { stats, tournaments } = await API.dashboard();
    document.getElementById('d-players').textContent     = stats.playerCount;
    document.getElementById('d-tournaments').textContent = stats.tournamentCount;
    document.getElementById('d-played').textContent      = stats.playedCount;
    document.getElementById('d-pending').textContent     = stats.pendingCount;

    const el = document.getElementById('dash-tournaments');
    if (!tournaments.length) { el.innerHTML = emptyState('🏆','No tournaments yet.'); return; }

    el.innerHTML = `
      <div class="section-header" style="margin-top:1.5rem"><h2>Tournament Overview</h2></div>
      <div class="t-overview">
        ${tournaments.map(t => `
          <div class="t-ov-card">
            <div class="t-ov-name">${esc(t.name)}</div>
            <div class="t-ov-meta">
              Players: <span>${t.playerCount || 0}</span> &nbsp;|&nbsp;
              Phase: <span><span class="badge badge-${t.phase}">${t.phase}</span></span><br>
              Matches: <span>${t.playedCount || 0}/${t.matchCount || 0}</span> &nbsp;|&nbsp;
              Fixtures: <span>${t.fixturesGenerated ? '✓ Generated' : '✗ Pending'}</span>
              ${t.championId ? `<br>🏆 Champion: <span style="color:var(--neon-yellow)">${esc(t.championId.playerName)}</span>` : ''}
            </div>
            <div class="progress-bar">
              <div class="progress-fill" style="width:${t.matchCount ? Math.round(t.playedCount/t.matchCount*100) : 0}%"></div>
            </div>
          </div>`).join('')}
      </div>`;
  } catch (err) {
    document.getElementById('dash-tournaments').innerHTML = `<div class="alert alert-error">${err.message}</div>`;
  }
}

// ── RESULTS ──────────────────────────────────────────────────────
async function loadResults() {
  const el = document.getElementById('results-container');
  el.innerHTML = '<div class="loading-pulse"></div><div class="loading-pulse"></div>';
  try {
    const { fixtures } = await API.getFixtures();
    const pending  = fixtures.filter(f => !f.played);
    const played   = fixtures.filter(f => f.played).reverse();

    if (!fixtures.length) { el.innerHTML = emptyState('⚽','No matches yet. Generate fixtures first.'); return; }

    // Group pending by tournament
    const tNames = {};
    try {
      const { tournaments } = await API.getTournaments();
      tournaments.forEach(t => { tNames[t._id] = t.name; });
    } catch(_) {}

    let html = '';

    if (pending.length) {
      html += `<div class="section-header"><h2>Pending Matches (${pending.length})</h2></div>`;
      const byT = groupByTournament(pending);
      Object.entries(byT).forEach(([tid, ms]) => {
        html += `<div style="margin-bottom:1.5rem">
          <div style="font-family:var(--font-mono);font-size:0.65rem;letter-spacing:0.15em;color:var(--neon-main);margin-bottom:0.8rem">◈ ${esc(tNames[tid] || 'Tournament')}</div>
          ${ms.map(m => matchRowAdmin(m, true)).join('')}
        </div>`;
      });
    }

    if (played.length) {
      html += `<div class="section-header" style="margin-top:1.5rem"><h2>Completed (${played.length})</h2></div>`;
      html += played.slice(0,50).map(m => matchRowAdmin(m, false)).join('');
    }

    el.innerHTML = html || emptyState('✅','All matches completed!');
  } catch (err) {
    el.innerHTML = `<div class="alert alert-error">${err.message}</div>`;
  }
}

function groupByTournament(matches) {
  const map = {};
  matches.forEach(m => {
    const tid = m.tournamentId || 'unknown';
    if (!map[tid]) map[tid] = [];
    map[tid].push(m);
  });
  return map;
}

function matchRowAdmin(m, clickable) {
  const home = m.homePlayer || {};
  const away = m.awayPlayer || {};
  const scoreHtml = m.played
    ? `<div class="mc-score">${m.homeScore} – ${m.awayScore}</div>`
    : `<div class="mc-score pending">vs</div>`;

  return `
    <div class="match-card ${clickable ? 'clickable' : ''}" onclick="${clickable || m.played ? `openScoreModal('${m._id}','${esc(home.playerName)}','${esc(away.playerName)}',${m.homeScore??0},${m.awayScore??0})` : ''}">
      <div class="mc-team right">
        <div class="mc-name">${esc(home.playerName||'TBD')}</div>
        <div class="mc-club">${esc(home.teamName||'')}</div>
      </div>
      ${scoreHtml}
      <div class="mc-team">
        <div class="mc-name">${esc(away.playerName||'TBD')}</div>
        <div class="mc-club">${esc(away.teamName||'')}</div>
      </div>
      <div class="mc-round">${m.round}</div>
      <div class="mc-actions">
        <button class="btn btn-sm ${m.played ? 'btn-warn' : 'btn-success'}" 
          onclick="event.stopPropagation(); openScoreModal('${m._id}','${esc(home.playerName)}','${esc(away.playerName)}',${m.homeScore??0},${m.awayScore??0})">
          ${m.played ? 'Edit' : 'Enter Score'}
        </button>
      </div>
    </div>`;
}

// ── ADMIN FIXTURES ────────────────────────────────────────────────
async function loadAdminFixtures() {
  const el     = document.getElementById('fixtures-admin-container');
  const stage  = document.getElementById('f-stage').value;
  const played = document.getElementById('f-played').value;

  el.innerHTML = '<div class="loading-pulse"></div><div class="loading-pulse"></div>';
  try {
    const params = {};
    if (stage) params.stage = stage;
    if (played !== '') params.played = played;

    const { fixtures, count } = await API.getFixtures(params);
    if (!fixtures.length) { el.innerHTML = emptyState('📋','No fixtures found.'); return; }

    const tNames = {};
    try {
      const { tournaments } = await API.getTournaments();
      tournaments.forEach(t => { tNames[t._id] = t.name; });
    } catch(_) {}

    const byT = groupByTournament(fixtures);
    let html = `<div style="font-family:var(--font-mono);font-size:0.68rem;color:var(--text-dim);margin-bottom:1rem">${count} match${count!==1?'es':''}</div>`;

    Object.entries(byT).forEach(([tid, ms]) => {
      html += `<div style="margin-bottom:2rem">
        <div class="section-header"><h2>${esc(tNames[tid]||'Tournament')}</h2></div>
        ${ms.map(m => matchRowAdmin(m, true)).join('')}
      </div>`;
    });

    el.innerHTML = html;
  } catch (err) {
    el.innerHTML = `<div class="alert alert-error">${err.message}</div>`;
  }
}

// ── PLAYERS ───────────────────────────────────────────────────────
async function loadPlayers() {
  const tbody = document.getElementById('admin-player-tbody');
  try {
    const { players } = await API.getPlayers();
    if (!players.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">No players registered yet</td></tr>';
      return;
    }
    tbody.innerHTML = players.map((p, i) => `
      <tr>
        <td style="font-family:var(--font-mono);color:var(--text-dim)">${i+1}</td>
        <td><strong>${esc(p.playerName)}</strong></td>
        <td style="color:var(--text-dim)">${esc(p.teamName)}</td>
        <td style="color:var(--neon-main);font-family:var(--font-mono);font-size:0.75rem">${p.tournamentId ? esc(p.tournamentId.name) : '—'}</td>
        <td style="color:var(--neon-acc);font-family:var(--font-mono);font-size:0.75rem">${p.groupId ? esc(p.groupId.name) : '—'}</td>
        <td style="font-family:var(--font-mono);font-size:0.72rem;color:var(--text-dim)">${fmtDate(p.registeredAt)}</td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty-cell" style="color:var(--neon-main)">${err.message}</td></tr>`;
  }
}

// ── GENERATE ──────────────────────────────────────────────────────
async function loadGenerate() {
  const el = document.getElementById('gen-tournaments');
  el.innerHTML = '<div class="loading-pulse"></div>';
  try {
    const { tournaments } = await API.getTournaments();
    if (!tournaments.length) { el.innerHTML = emptyState('🏆','No tournaments found.'); return; }

    el.innerHTML = tournaments.map(t => `
      <div class="gen-card">
        <div class="gen-info">
          <div class="gen-name">${esc(t.name)}</div>
          <div class="gen-meta">
            Players: ${t.playerCount || 0} &nbsp;|&nbsp;
            Phase: <span class="badge badge-${t.phase}">${t.phase}</span> &nbsp;|&nbsp;
            Group fixtures: ${t.fixturesGenerated ? '✓ Done' : '✗ Not generated'} &nbsp;|&nbsp;
            Knockout: ${t.knockoutGenerated ? '✓ Done' : '✗ Not generated'}
          </div>
        </div>
        <div class="gen-actions">
          <button class="btn btn-sm btn-success" onclick="genGroup('${t._id}')" ${t.fixturesGenerated ? 'disabled style="opacity:0.4"' : ''}>
            ⚡ Gen Group Fixtures
          </button>
          <button class="btn btn-sm btn-admin" onclick="genKnockout('${t._id}')" ${t.knockoutGenerated ? 'disabled style="opacity:0.4"' : !t.fixturesGenerated ? 'disabled style="opacity:0.4"' : ''}>
            🔥 Gen Knockout
          </button>
        </div>
      </div>`).join('');
  } catch (err) {
    el.innerHTML = `<div class="alert alert-error">${err.message}</div>`;
  }
}

async function genGroup(tid) {
  try {
    const res = await API.generateGroup(tid);
    showAlert('gen-alert','success', `✓ ${res.message} — ${res.matchCount} matches created.`);
    loadGenerate();
  } catch (err) {
    showAlert('gen-alert','error', err.message);
  }
}

async function genKnockout(tid) {
  try {
    const res = await API.generateKnockout(tid);
    showAlert('gen-alert','success', `✓ ${res.message} — ${res.matchCount} knockout matches created. ${res.byeCount} bye(s) given.`);
    loadGenerate();
  } catch (err) {
    showAlert('gen-alert','error', err.message);
  }
}

// ── SCORE MODAL ───────────────────────────────────────────────────
let currentMatchId = null;

function openScoreModal(matchId, homeName, awayName, homeScore, awayScore) {
  currentMatchId = matchId;
  document.getElementById('modal-home-name').textContent = homeName;
  document.getElementById('modal-away-name').textContent = awayName;
  document.getElementById('modal-home').value = homeScore || 0;
  document.getElementById('modal-away').value = awayScore || 0;
  document.getElementById('modal-meta').textContent = `Match ID: ${matchId}`;
  document.getElementById('modal-alert').innerHTML = '';
  document.getElementById('score-modal').classList.add('open');
}

function closeScoreModal() {
  document.getElementById('score-modal').classList.remove('open');
  currentMatchId = null;
}

function closeModal(e) {
  if (e.target === document.getElementById('score-modal')) closeScoreModal();
}

async function saveResult() {
  if (!currentMatchId) return;
  const hs  = parseInt(document.getElementById('modal-home').value);
  const as  = parseInt(document.getElementById('modal-away').value);
  const btn = document.getElementById('modal-save-btn');

  if (isNaN(hs) || isNaN(as) || hs < 0 || as < 0) {
    showAlert('modal-alert','error','Scores must be valid non-negative numbers.', 3000);
    return;
  }

  btn.disabled    = true;
  btn.textContent = '⏳ Saving…';
  try {
    await API.updateResult(currentMatchId, { homeScore: hs, awayScore: as });
    closeScoreModal();
    // Refresh current tab
    const activeTab = TABS.find(t => document.getElementById(`tab-${t}`).classList.contains('active'));
    if (activeTab === 'results')  loadResults();
    if (activeTab === 'fixtures') loadAdminFixtures();
    if (activeTab === 'dashboard') loadDashboard();
  } catch (err) {
    showAlert('modal-alert','error', err.message, 0);
  } finally {
    btn.disabled    = false;
    btn.textContent = '✓ Save Result';
  }
}

// ── INIT ──────────────────────────────────────────────────────────
(async function init() {
  const token = localStorage.getItem('eftm_admin_token');
  if (token) {
    try {
      await API.me();
      showAdminApp();
      switchTab('dashboard');
    } catch (_) {
      localStorage.removeItem('eftm_admin_token');
      showLoginScreen();
    }
  } else {
    showLoginScreen();
  }
})();
